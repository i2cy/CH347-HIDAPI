#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: i2cy(i2cy@outlook.com)
# Project: CH347PythonLib
# Filename: __init__
# Created on: 2022/11/11

from .spi import CH347HIDDev
